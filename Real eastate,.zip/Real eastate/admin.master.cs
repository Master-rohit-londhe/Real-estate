﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage2 : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void developer_Click(object sender, EventArgs e)
    {
        Response.Redirect("developeradmin.aspx");
    }
    protected void realestate_Click(object sender, EventArgs e)
    {
        Response.Redirect("AddRealEstate.aspx");
    }
    protected void fixedvalues_Click(object sender, EventArgs e)
    {
        Response.Redirect("FixedValue.aspx");
    }
    protected void developer_Click1(object sender, EventArgs e)
    {
        Response.Redirect("developeradmin.aspx");
    }
    protected void realestate_Click1(object sender, EventArgs e)
    {
        Response.Redirect("AddRealEstate.aspx");
    }
    protected void fixedvalues_Click1(object sender, EventArgs e)
    {
        Response.Redirect("Adminenquiry.aspx");
    }
    protected void logout_Click(object sender, EventArgs e)
    {
        Response.Redirect("index.aspx");
    }
}
