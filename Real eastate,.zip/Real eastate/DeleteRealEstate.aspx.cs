﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
public partial class Default2 : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void raeldelete_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("delete from realestate where Id='" + deleteid.Text + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
            
            msg.Visible = true;
           
            Response.Write("<script>alert('Your data Deleted successfully')</script>");
            deleteid.SelectedItem.Text= "";
            
            // documents.SelectedItem.Text= null;
        }
        catch (Exception e1)
        {
            msg.Visible = true;
            msg.Text = "error=" + e1.Message;
        }
    }
    protected void home_Click(object sender, EventArgs e)
    {
        Response.Redirect("index.aspx");
    }
    protected void developeradd_Click(object sender, EventArgs e)
    {
        Response.Redirect("AddRealEstate.aspx");
    }
    protected void updatedeveloper_Click(object sender, EventArgs e)
    {
        Response.Redirect("UpdateRealEstate.aspx");
    }
    protected void deletedeveloper_Click(object sender, EventArgs e)
    {
        Response.Redirect("DeleteRealEstate.aspx");
    }
    protected void logout_Click(object sender, EventArgs e)
    {
        Response.Redirect("index.aspx");
    }
    protected void realcancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("adminlog.aspx");
    }
}