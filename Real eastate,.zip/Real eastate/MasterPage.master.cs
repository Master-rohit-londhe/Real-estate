﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void home_Click(object sender, EventArgs e)
    {
        Response.Redirect("index.aspx");
    }
    protected void buynewflat_Click(object sender, EventArgs e)
    {
        Response.Redirect("buynewflat.aspx");
    }
    protected void rentnewflat_Click(object sender, EventArgs e)
    {
        Response.Redirect("rentnewflat.aspx");
    }
    protected void aboutus_Click(object sender, EventArgs e)
    {
        Response.Redirect("aboutus.aspx");
    }
    protected void feedback_Click(object sender, EventArgs e)
    {
        Response.Redirect("feedback.aspx");
    }
    protected void logout_Click(object sender, EventArgs e)
    {
        Response.Redirect("index.aspx");
    }
    protected void adminlogin_Click(object sender, EventArgs e)
    {
        Response.Redirect("adminlog.aspx");
    }

    protected void customerlogin_Click1(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void developerlogin_Click(object sender, EventArgs e)
    {
        Response.Redirect("developer.aspx");
    }
}
