﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }
    protected void citywise_Click(object sender, EventArgs e)
    {
        Response.Redirect("buynewflat.aspx");
    }
    protected void locationwise_Click(object sender, EventArgs e)
    {
        Response.Redirect("locationwise.aspx");
    }
    protected void bhkwise_Click(object sender, EventArgs e)
    {
        Response.Redirect("bhkwise.aspx");
    }
    protected void all_Click(object sender, EventArgs e)
    {
        Response.Redirect("all.aspx");
    }
    protected void propertytype_Click(object sender, EventArgs e)
    {
        Response.Redirect("propertytype.aspx");
    }
    protected void Button1_Command(object sender, CommandEventArgs e)
    {
        Response.Redirect("customer.aspx?id="+e.CommandArgument);
    }
    protected void search_Click(object sender, EventArgs e)
    {

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }
    protected void view_Click(object sender, EventArgs e)
    {
    
    }
    protected void view_Command(object sender, CommandEventArgs e)
    {
        Response.Redirect("customer.aspx?id=" + e.CommandArgument);
    }
}