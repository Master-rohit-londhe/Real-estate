﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);


    protected void login_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        con.Open();
        SqlCommand cmd = new SqlCommand("Select * from customer where Id='" + customerid.Text + "' and password ='" + password.Text + "'", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            Session["Id"] = customerid.Text;

            Response.Redirect("myprofile.aspx");

        }


        else
        {
            Response.Write("<script>alert('Please enter valid Username and Password')</script>");
        }

       
    }
    protected void register_Click(object sender, EventArgs e)
    {
        Response.Redirect("customerregistration.aspx");
    }
    protected void cancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("index.aspx");
    }
}