﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
public partial class Default2 : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (upload.PostedFile != null && upload.PostedFile.ContentLength > 0)
            UpLoadAndDisplay();


    }
    private void UpLoadAndDisplay()
    {
        string imgName = upload.FileName;
        string imgPath = "profile/" + imgName;
        int imgSize = upload.PostedFile.ContentLength;
        if (upload.PostedFile != null && upload.PostedFile.FileName != "")
        {

            upload.SaveAs(Server.MapPath(imgPath));
            img.ImageUrl = "~/" + imgPath;
        }
    }
    protected void realcity_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        con.Open();
        SqlDataAdapter Adp = new SqlDataAdapter("select location from location where city='" + realcity.SelectedItem.Text + "' ", con);
        DataTable Dt = new DataTable();
        Adp.Fill(Dt);
        realloc.DataSource = Dt;
        realloc.DataTextField = "location";
        realloc.DataBind();
    }

    protected void realupate_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("update realestate set developername='"+developernm.SelectedItem.Text+"', developerid='" + developerid.Text + "', contactno='" + no.Text + "', city='" + realcity.SelectedItem.Text + "', location='" + realloc.SelectedItem.Text + "', bhk='" + realbhk.SelectedItem.Text + "',  buyrent='" + buyrent.SelectedItem + "',  price='" + realprice.Text + "',  propertytype='" + realtype.SelectedItem.Text + "', img='" + img.ImageUrl + "' where Id='" + (updaterealid.SelectedItem.Text).ToString() + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
            
            msg.Visible = true;
            
            Response.Write("<script>alert('Your data updated successfully')</script>");
            updaterealid.ClearSelection();
            developernm.SelectedIndex = 0;
            developerid.Text = "";
            no.Text = "";
            realcity.SelectedIndex =0;
            realloc.SelectedIndex =0 ;
            realbhk.SelectedIndex= 0;
            buyrent.SelectedValue = "";
            realprice.Text = "";
            realtype.SelectedIndex= 0;
            img.ImageUrl = "";
            
        }
        catch (Exception e1)
        {
            msg.Visible = true;
            msg.Text = "error=" + e1.Message;
        }

    }


    protected void search_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from realestate where Id='" + updaterealid.Text+ "' ", con);

            SqlDataReader rd = cmd.ExecuteReader();
            rd.Read();
            if (rd.HasRows)
            {
                updaterealid.Text = rd[0].ToString();
                developernm.Text = rd[1].ToString();
                developerid.Text = rd[2].ToString();
                no.Text = rd[3].ToString();
                realcity.SelectedValue = rd[4].ToString();
                realloc.SelectedItem.Text = rd[5].ToString();
                realbhk.SelectedValue = rd[6].ToString();
                buyrent.SelectedValue = rd[7].ToString();
                realprice.Text = rd[8].ToString();
                realtype.SelectedValue = rd[9].ToString();
                img.ImageUrl = rd[10].ToString();
                rd.Close();
                con.Close();
                //   GridView1.DataBind();
                msg.Visible = false;
            }
            

        }
        catch (Exception e1)
        {
            msg.Visible = true;
            msg.Text = "error=" + e1.Message;
        }
    }
    protected void home_Click(object sender, EventArgs e)
    {
        Response.Redirect("index.aspx");
    }
    protected void developeradd_Click(object sender, EventArgs e)
    {
        Response.Redirect("AddRealEState.aspx");
    }
    protected void updatedeveloper_Click(object sender, EventArgs e)
    {
        Response.Redirect("UpdateRealEState.aspx");
    }
    protected void deletedeveloper_Click(object sender, EventArgs e)
    {
        Response.Redirect("DeleteRealEState.aspx");
    }
    protected void logout_Click(object sender, EventArgs e)
    {
        Response.Redirect("index.aspx");
    }
    protected void constructname_TextChanged(object sender, EventArgs e)
    {

    }
    protected void searchnm_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("select developerid from realestate where developername='" + developernm.SelectedItem.Text + "' ", con);

            SqlDataReader rd = cmd.ExecuteReader();
            rd.Read();
            if (rd.HasRows)
            {


                developerid.Text = rd[0].ToString();

                rd.Close();
                con.Close();
                //   GridView1.DataBind();
                msg.Visible = false;
            }


        }
        catch (Exception e1)
        {
            msg.Visible = true;
            msg.Text = "error=" + e1.Message;
        }
    }
    protected void developernm_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        con.Open();
        SqlDataAdapter Adp = new SqlDataAdapter("select Id from realestate where developername='" + developernm.SelectedItem.Text + "' ", con);
        DataTable Dt = new DataTable();
        Adp.Fill(Dt);
        updaterealid.DataSource = Dt;
        updaterealid.DataTextField = "Id";
        updaterealid.DataBind();
       
    }
    protected void developerid_TextChanged(object sender, EventArgs e)
    {
        
        


        }

    protected void updaterealid_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void realcancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("adminlog.aspx");
    }
}
