﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void developeradd_Click(object sender, EventArgs e)
    {
        Response.Redirect("developeradmin.aspx");
    }
    protected void updatedeveloper_Click(object sender, EventArgs e)
    {
        Response.Redirect("updatedeveloper.aspx");
    }
    protected void deletedeveloper_Click(object sender, EventArgs e)
    {
        Response.Redirect("deletedeveloper.aspx");
    }
    protected void logout_Click(object sender, EventArgs e)
    {
        Response.Redirect("index.aspx");
    }
    protected void delete_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("delete from developer where Id='" + Convert.ToInt32(developerid.Text).ToString() + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
            
            message.Visible = true;
            message.Text = "Data Deleted Successfully";
            developerid.SelectedItem.Text= "";
            
            // documents.SelectedItem.Text= null;
        }
        catch (Exception e1)
        {
            message.Visible = true;
            message.Text = "error=" + e1.Message;
        }
    }
    protected void cancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("adminlog.aspx");
    }
}