﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void developeradd_Click(object sender, EventArgs e)
    {
        Response.Redirect("developeradmin.aspx");
    }
    protected void updatedeveloper_Click(object sender, EventArgs e)
    {
        Response.Redirect("updatedeveloper.aspx");
    }
    protected void deletedeveloper_Click(object sender, EventArgs e)
    {
        Response.Redirect("deletedeveloper.aspx");
    }
    protected void logout_Click(object sender, EventArgs e)
    {
        Response.Redirect("index.aspx");
    }
    protected void home_Click(object sender, EventArgs e)
    {
        Response.Redirect("index.aspx");
    }
    protected void search_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from developer where Id=' " + developerid.Text + "' ", con);

            SqlDataReader rd = cmd.ExecuteReader();
            rd.Read();
            if (rd.HasRows)
            {
                developerid.Text = rd[0].ToString();
                developername.Text = rd[1].ToString();
                gender.SelectedValue = rd[2].ToString();
                contactnumber.Text = rd[3].ToString();
                email.Text = rd[4].ToString();
                companyname.Text = rd[5].ToString();
                city.Text = rd[6].ToString();
                username.Text = rd[7].ToString();
                password.Text = rd[8].ToString();
                rd.Close();
                con.Close();

                message.Visible = false;
            }
            else
            {
               message.Text = "not found";
            }
        }
        catch (Exception e1)
        {
            message.Visible = true;
            message.Text = "error=" + e1.Message;
        }
    
    }
    protected void update_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("update developer set developername='" + developername.Text + "',gender='" + gender.SelectedItem.Text + "',contactno='" + contactnumber.Text + "', email='" + email.Text + "', companyname='" + companyname.Text + "',city='" + city.Text + "', username='" + username.Text + "',password='" + password.Text+ "' where Id='" + Convert.ToInt32(developerid.Text).ToString() + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
           
            message.Visible = true;
            message.Text = "your data updated successfully";
           
            developername.Text = "";
            gender.SelectedValue = "";
            contactnumber.Text = "";
            email.Text = "";
            city.Text = "";
            username.Text = "";
            password.Text = "";
            // documents.SelectedItem.Text= null;
        }
        catch (Exception e1)
        {
            message.Visible = true;
            message.Text = "error=" + e1.Message;
        }

    }
    protected void cancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("adminlog.aspx");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from developer where Id='" + developerid.Text + "' ", con);

            SqlDataReader rd = cmd.ExecuteReader();
            rd.Read();
            if (rd.HasRows)
            {
                developerid.Text = rd[0].ToString();
                developername.Text = rd[1].ToString();
                gender.SelectedValue = rd[2].ToString();
                contactnumber.Text = rd[3].ToString();
                email.Text = rd[4].ToString();
                companyname.Text = rd[5].ToString();
                city.Text = rd[6].ToString();
                username.Text = rd[7].ToString();
                password.Text = rd[8].ToString();


                rd.Close();
                con.Close();
                //   GridView1.DataBind();
                message.Visible = false;
            }


        }
        catch (Exception e1)
        {
            message.Visible = true;
            message.Text = "error=" + e1.Message;
        }
    }
}