﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


public partial class _Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
   
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void citywise_Click(object sender, EventArgs e)
    {
        Response.Redirect("buynewflat.aspx");
    }
    protected void locationwise_Click(object sender, EventArgs e)
    {
        Response.Redirect("locationwise.aspx");
    }
    protected void bhkwise_Click(object sender, EventArgs e)
    {
        Response.Redirect("bhkwise.aspx");
    }
    protected void all_Click(object sender, EventArgs e)
    {
        Response.Redirect("all.aspx");
    }
    protected void propertytype_Click(object sender, EventArgs e)
    {
        Response.Redirect("propertytype.aspx");
    }
    protected void cityname_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        con.Open();
        SqlDataAdapter Adp = new SqlDataAdapter("select propertytype from realestate where city='" + cityname.SelectedItem.Text + "' ", con);
        DataTable Dt = new DataTable();
        Adp.Fill(Dt);
        property.DataSource = Dt;
        property.DataTextField = "propertytype";
        property.DataBind();
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    
    protected void viewdetails_Command(object sender, CommandEventArgs e)
    {
        Response.Redirect("customer.aspx?id=" + e.CommandArgument);
    }
    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {

    }
    protected void search_Click(object sender, EventArgs e)
    {

    }
}