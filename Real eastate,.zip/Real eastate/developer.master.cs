﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;


public partial class MasterPage2 : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        

    }
    protected void home_Click(object sender, EventArgs e)
    {
        Response.Redirect("index.aspx");
    }
    protected void logout_Click(object sender, EventArgs e)
    {
        Response.Redirect("index.aspx");
    }
    protected void myprofile_Click(object sender, EventArgs e)
    {
        Response.Redirect("developerprofile.aspx");
    }
    protected void addrealestate_Click(object sender, EventArgs e)
    { 


        Response.Redirect("developeraddrealestate.aspx");
    }
    protected void updaterealestate_Click(object sender, EventArgs e)
    {
        Response.Redirect("developerupdaterealestate.aspx");
    }
    protected void delterealestate_Click(object sender, EventArgs e)
    {
        Response.Redirect("developerdeleterealestate.aspx");
    }
    protected void fixedvalue_Click(object sender, EventArgs e)
    {
        Response.Redirect("developerfixedvalue.aspx");
    }
}
