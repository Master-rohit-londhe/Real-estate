﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;


public partial class _Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        HiddenField1.Value = Session["Id"].ToString();
        customerid.Text = HiddenField1.Value;
    }
   
    
    protected void update_Click1(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("update customer set customername='" + customername.Text + "',address='" + address.Text + "',mobilenumber='" + mobno.Text + "', emailid='" + emailid.Text + "',gender='" + gender.SelectedItem.Text + "', username='" + username.Text + "',password='" + password.Text + "' where Id='" + (customerid.Text).ToString() + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();

            message.Visible = true;
            message.Text = "Your Data Updated Successfully";
           
            customername.Text = "";
            address.Text = "";
            mobno.Text = "";
            emailid.Text = "";
            gender.SelectedValue = "";
            username.Text = "";
            password.Text = "";
            // documents.SelectedItem.Text= null;
        }
        catch (Exception e1)
        {
            message.Visible = true;
            message.Text = "error=" + e1.Message;
        }
        HiddenField1.Value = Session["Id"].ToString();
        customerid.Text = HiddenField1.Value;
    }

    protected void search_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from customer where Id=' " + customerid.Text + "' ", con);

            SqlDataReader rd = cmd.ExecuteReader();
            rd.Read();
            if (rd.HasRows)
            {
                customerid.Text = rd[0].ToString();
               customername.Text= rd[1].ToString();
                address.Text = rd[2].ToString();
                mobno.Text= rd[3].ToString();
                emailid.Text = rd[4].ToString();
                gender.SelectedValue = rd[5].ToString();
               username.Text = rd[6].ToString();
                
                password.Text = rd[7].ToString();
                rd.Close();
                con.Close();

                message.Visible = false;
            }
            else
            {
                message.Text = "not found";
            }
        }
        catch (Exception e1)
        {
            message.Visible = true;
            message.Text = "error=" + e1.Message;
        }
    
    }

    protected void cancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("customer.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from customer where Id='" + customerid.Text + "' ", con);

            SqlDataReader rd = cmd.ExecuteReader();
            rd.Read();
            if (rd.HasRows)
            {
                customerid.Text = rd[0].ToString();
                customername.Text = rd[1].ToString();
                address.Text = rd[2].ToString();
                mobno.Text = rd[3].ToString();
                emailid.Text = rd[4].ToString();
                gender.SelectedValue = rd[5].ToString();
                username.Text = rd[6].ToString();
                password.Text = rd[7].ToString();
               

                rd.Close();
                con.Close();
                //   GridView1.DataBind();
                message.Visible = false;
            }


        }
        catch (Exception e1)
        {
            message.Visible = true;
            message.Text = "error=" + e1.Message;
        }
    }
}
