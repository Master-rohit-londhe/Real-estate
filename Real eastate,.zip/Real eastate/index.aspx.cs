﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void adminlogin_Click(object sender, EventArgs e)
    {
        Response.Redirect("adminlog.aspx");
    }
    protected void developerlogin_Click(object sender, EventArgs e)
    {
        Response.Redirect("developer.aspx");
    }
    protected void customerlogin_Click1(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
}