﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void citywise_Click(object sender, EventArgs e)
    {
        Response.Redirect("rentnewflat.aspx");
    }
    protected void locationwise_Click(object sender, EventArgs e)
    {
        Response.Redirect("locationrent.aspx");
    }
    protected void bhkwise_Click(object sender, EventArgs e)
    {
        Response.Redirect("bhkrent.aspx");
    }
    protected void propertytype_Click(object sender, EventArgs e)
    {
        Response.Redirect("propertyrent.aspx");
    }
    protected void all_Click(object sender, EventArgs e)
    {
        Response.Redirect("allrent.aspx");
    }
    protected void search_Click(object sender, EventArgs e)
    {

    }
}