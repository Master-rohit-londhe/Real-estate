﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        HiddenField1.Value = Session["Id"].ToString();
        developerid.Text = HiddenField1.Value;
    }
    protected void search_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from developer where Id=' " + developerid.Text + "' ", con);

            SqlDataReader rd = cmd.ExecuteReader();
            rd.Read();
            if (rd.HasRows)
            {
                
                developername.Text = rd[0].ToString();
                gender.SelectedValue = rd[1].ToString();
                contactnumber.Text = rd[2].ToString();
                email.Text = rd[3].ToString();
                companyname.Text = rd[4].ToString();
                city.Text = rd[5].ToString();
                username.Text = rd[6].ToString();
                password.Text = rd[7].ToString();
                rd.Close();
                con.Close();

                message.Visible = false;
            }
            else
            {
                message.Text = "not found";
            }
        }
        catch (Exception e1)
        {
            message.Visible = true;
            message.Text = "error=" + e1.Message;
        }
       
    
    }
    protected void update_Click(object sender, EventArgs e)
    {

        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from developer where Id='" + developerid.Text + "' ", con);

            SqlDataReader rd = cmd.ExecuteReader();
            rd.Read();
            if (rd.HasRows)
            {
                developerid.Text = rd[0].ToString();
                developername.Text = rd[1].ToString();
                gender.SelectedValue = rd[2].ToString();
                contactnumber.Text = rd[3].ToString();
                email.Text = rd[4].ToString();
                companyname.Text = rd[5].ToString();
                city.Text = rd[6].ToString();
                username.Text = rd[7].ToString();
                password.Text = rd[8].ToString();

                rd.Close();
                con.Close();
                //   GridView1.DataBind();
                message.Visible = false;
            }


        }
        catch (Exception e1)
        {
            message.Visible = true;
            message.Text = "error=" + e1.Message;
        }
       
    }

    protected void cancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("developer.aspx");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from developer where Id='" + developerid.Text + "' ", con);

            SqlDataReader rd = cmd.ExecuteReader();
            rd.Read();
            if (rd.HasRows)
            {
                developerid.Text = rd[0].ToString();
                developername.Text = rd[1].ToString();
                gender.SelectedValue = rd[2].ToString();
                contactnumber.Text = rd[3].ToString();
                email.Text = rd[4].ToString();
                companyname.Text = rd[5].ToString();
                city.Text = rd[6].ToString();
                username.Text = rd[7].ToString();
                password.Text = rd[8].ToString();
                
                rd.Close();
                con.Close();
                //   GridView1.DataBind();
                message.Visible = false;
            }


        }
        catch (Exception e1)
        {
            message.Visible = true;
            message.Text = "error=" + e1.Message;
        }
    }
}