﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        HiddenField1.Value = Session["Id"].ToString();
       
    }
    protected void raeldelete_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("delete from realestate where Id='" + deleteid.SelectedItem.Text + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();

            msg.Visible = true;
            msg.Text = "data deleted successfully";
            deleteid.SelectedItem.Text = "";

            // documents.SelectedItem.Text= null;
        }
        catch (Exception e1)
        {
            msg.Visible = true;
            msg.Text = "error=" + e1.Message;
        }
        HiddenField1.Value = Session["Id"].ToString();
        
    }
    protected void realcancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("developer.aspx");
    }
}