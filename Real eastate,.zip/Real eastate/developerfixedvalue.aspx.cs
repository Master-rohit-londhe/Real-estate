﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
public partial class _Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);

    protected void Page_Load(object sender, EventArgs e)
    {

    }
   
    protected void save1_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into city values('" + city.Text + "')", con);
            cmd.ExecuteNonQuery();
            con.Close();

            msg.Visible = true;
            msg.Text = "your data save successfully";
            city.Text = "";

            // documents.SelectedItem.Text= null;
        }
        catch (Exception e1)
        {
            msg.Visible = true;
            msg.Text = "error=" + e1.Message;
        }
    }
    protected void save2_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into location values('" + cityloc.SelectedItem.Text + "','" + location.Text + "')", con);
            cmd.ExecuteNonQuery();
            con.Close();

            msg2.Visible = true;
            msg2.Text = "your data save successfully";
            cityloc.SelectedIndex = 0;
            location.Text = "";

            // documents.SelectedItem.Text= null;
        }
        catch (Exception e1)
        {
            msg2.Visible = true;
            msg2.Text = "error=" + e1.Message;
        }
    }
    protected void save3_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into type values('" + property.Text + "')", con);
            cmd.ExecuteNonQuery();
            con.Close();

            msg1.Visible = true;
            msg1.Text = "your data save successfully";
            property.Text = "";

            // documents.SelectedItem.Text= null;
        }
        catch (Exception e1)
        {
            msg1.Visible = true;
            msg1.Text = "error=" + e1.Message;
        }
    }

    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void DropDownList2_SelectedIndexChanged1(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        con.Open();
        SqlDataAdapter Adp = new SqlDataAdapter("select location from location where city='" + citybhk.SelectedItem.Text + "' ", con);
        DataTable Dt = new DataTable();
        Adp.Fill(Dt);
        locbhk.DataSource = Dt;
        locbhk.DataTextField = "location";
        locbhk.DataBind();
    }
    protected void save5_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into bhk values('" + citybhk.SelectedItem.Text + "','" + locbhk.SelectedItem.Text + "','" + bhksave.Text + "')", con);
            cmd.ExecuteNonQuery();
            con.Close();

            msg3.Visible = true;
            msg3.Text = "your data save successfully";
            citybhk.SelectedIndex = 0;
            locbhk.SelectedIndex = 0;
            bhksave.Text = "";

            // documents.SelectedItem.Text= null;
        }
        catch (Exception e1)
        {
            msg3.Visible = true;
            msg3.Text = "error=" + e1.Message;
        }

    }
    protected void DropDownList4_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        con.Open();
        SqlDataAdapter Adp = new SqlDataAdapter("select location from location where city='" + cityprice.SelectedItem.Text + "' ", con);
        DataTable Dt = new DataTable();
        Adp.Fill(Dt);
        locprice.DataSource = Dt;
        locprice.DataTextField = "location";
        locprice.DataBind();

    }
    protected void save6_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into price values('" + cityprice.SelectedItem.Text + "','" + locprice.SelectedItem.Text + "','" + bhkprice.SelectedItem.Text + "','" + pricefrom.Text + "','" + priceto.Text + "')", con);
            cmd.ExecuteNonQuery();
            con.Close();

            message.Visible = true;
            message.Text = "your data save successfully";
            cityprice.SelectedIndex = 0;
            locprice.SelectedIndex = 0;
            bhkprice.SelectedIndex = 0;
            pricefrom.Text = "";
            priceto.Text = "";

            // documents.SelectedItem.Text= null;
        }
        catch (Exception e1)
        {
            message.Visible = true;
            message.Text = "error=" + e1.Message;
        }

    }



    protected void addcity_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 0;
    }
    protected void addtype_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 1;
    }
    protected void addtype1_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 2;
    }
    protected void addbhk_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 3;
    }
    protected void addprice_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 4;
    }
}